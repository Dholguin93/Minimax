/*******************
 * Christian A. Duncan
 * CSC350: Intelligent Systems
 * Spring 2017
 *
 * AI Game Client
 * This project is designed to link to a basic Game Server to test
 * AI-based solutions.
 * See README file for more details.
 ********************/

package cad.ai.game;

import java.util.Random;
import java.util.ArrayList;
import cad.ai.game.*;

/***********************************************************
 * The AI system for a OthelloGame.
 *   Most of the game control is handled by the Server but
 *   the move selection is made here - either via user or an attached
 *   AI system.
 ***********************************************************/
public class OthelloAI extends AbstractAI
 {
    public OthelloGame game;  // The game that this AI system is playing
    public OthelloGame practiceGame; 
    protected Random ran;
    int currentPlayer; 
    
    public OthelloAI()
     {
    	game = null;
    	ran = new Random();
        practiceGame = new OthelloGame(-1, null, null, false, 0);
    }

    public synchronized void attachGame(Game g) 
    {
    	game = (OthelloGame) g;
        currentPlayer = game.getPlayer();
    }
    
    /**
     * Returns the Move as a String "rc" (e.g. 2b)
     **/
    public synchronized String computeMove() 
    {
    	if (game == null) 
        {
    	    System.err.println("CODE ERROR: AI is not attached to a game.");
    	    return "0a";
    	}
	
	    char[][] board = (char[][]) game.getStateAsObject();

        // Determine Maximum score among all opponent's options (max of min)
        OthelloGame.Action bestAction = null;

        // Lowest Integer Value 
        int bestScore = Integer.MIN_VALUE;  

        // Possible actions the AI is able to make, based upon whether it's home or away 
        ArrayList<OthelloGame.Action> actions = game.getActions(currentPlayer);

        // For every actions
        for (OthelloGame.Action a: actions)
        {
            // Calculate the score based upon whether the AI is home or away.. 
            // Home wants to maximize it's score!
            // Away wants to minimize it's score!
            int score = (currentPlayer == 0) ? minValue(board, a) : -maxValue(board, a); 
            if (score > bestScore) 
            {
                bestAction = a;
                bestScore = score;
            }
        }

        // First get the list of possible moves
        // Now just pick of them out at random
        System.out.println("Choosing Action:" + bestAction.toString() + ", Score:" + bestScore);
        return bestAction.toString();
    }	

    
    // Away wishes to MINimize the score.
    // Board is the current board state
    // Action is the action the other player wants to make
    private int minValue(char[][] board, OthelloGame.Action action) 
    {
        // Determine if the board is a terminal board, in addition to updating the working board to reflect our clone 
        practiceGame.updateState(0, board);

        if(action != null)
        {
            boolean res = practiceGame.processMove(0,action.row,action.col);
            System.out.println("MIN: Action Row: " + action.row+ " Action Col: " + action.col + " Result: " + res);
            practiceGame.displayState();
            // Determines the winner ... 
            if (practiceGame.computeWinner()) 
            {
                // We have a winner - return its Utility
                //   1 for Player wins, -1 for Player loses, 0 for Tie
                int w = practiceGame.getWinner();
                return w < 0 ? 0 : w == 0 ? 1 : -1; // Try to win big here!
            }
        }
        else System.out.println("Action isn't defined");

        // Once again determine the possible actions based upon the other player 
        ArrayList<OthelloGame.Action> actions = practiceGame.getActions(1);
        if(actions.size() == 0) return maxValue((char[][])(practiceGame.getStateAsObject()), null);


        // Determine Maximum value among all possible actions
        int bestScore = Integer.MAX_VALUE; // Positive "Infinity"
        for (OthelloGame.Action a: actions)
        {
            int score = maxValue((char[][])practiceGame.getStateAsObject(), a); // Here
            if (score < bestScore) bestScore = score;
        }

        return bestScore;
    }

    // Home wishes to MAXimize the score.
    // Board is the current board state
    // Action is the action the other player wants to make
    private int maxValue(char[][] board, OthelloGame.Action action) 
    {
        // Determine if the board is a terminal board, in addition to updating the working board to reflect our clone 
        practiceGame.updateState(1, board);
        if(action != null)
        {
            boolean res = practiceGame.processMove(1,action.row,action.col);
            System.out.println("MAX: Action Row: " + action.row+ " Action Col: " + action.col + " Result: " + res);
            practiceGame.displayState();
            // Determines the winner ... 
            if (practiceGame.computeWinner()) 
            {
                // We have a winner - return its Utility
                //   1 for Player wins, -1 for Player loses, 0 for Tie
                int w = practiceGame.getWinner();
                return w < 0 ? 0 : w == 0 ? 1 : -1; // Try to win big here!
            }
        }
        else System.out.println("Action isn't defined");

        // Once again determine the possible actions based upon the player, and behind the scenes, our working baord aka clone 
        ArrayList<OthelloGame.Action> actions = practiceGame.getActions(0);
        if(actions.size() == 0) return minValue((char[][])(practiceGame.getStateAsObject()), null);

        // Determine Maximum value among all possible actions
        int bestScore = Integer.MIN_VALUE; // Positive "Infinity"
        for (OthelloGame.Action a: actions)
        {
            int score = minValue((char[][])(practiceGame.getStateAsObject()), a); // Here
            if (score > bestScore) bestScore = score;
        }

        return bestScore;
    }

    public String boardToString(char[][] board)
    {
        StringBuffer buffer = new StringBuffer();
        for(int i = 0; i < board.length; i++)
        {
            for(int j = 0; j < board.length; j++)
            {
                buffer.append(board[i][j]);
                buffer.append(",");
            }
        }

        return buffer.toString();
    }

    /**
     * Inform AI who the winner is
     *   result is either (H)ome win, (A)way win, (T)ie
     **/
    @Override
    public synchronized void postWinner(char result) {
	// This AI probably wants to store what it has learned
	// about this particular game.
	game = null;  // No longer playing a game though.
    }

    /**
     * Shutdown the AI - allowing it to save its learned experience
     **/
    @Override
    public synchronized void end() {
	// This AI probably wants to store (in a file) what
	// it has learned from playing all the games so far...
    }
}
